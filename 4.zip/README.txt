Please DO NOT delete prep.sh or any other file included in the submission.

To run the submission, simply execute:
	
	For sjf:
	sh run_sjf.sh <path-to-input-dat-file>
	
	For rr:
	sh run_rr.sh <path-to-input-dat-file>

This will print all the required process-wise data and average system data on the screen.

------------------------------------------------------------------------------------------------------------------------

To 1) run the submission and 2) get time-unit-wise cpu and io occupancy data, execute:
	
	For sjf:
	sh run_sjf.sh <path-to-input-dat-file> <output-file-name>
	
	For rr:
	sh run_rr.sh <path-to-input-dat-file> <output-file-name>

------------------------------------------------------------------------------------------------------------------------

To 1) run the submission and 2) get time-unit-wise cpu and io occupancy data and 3) only print average system details instead of the process wise data, execute:
	
	For sjf:
	sh run_sjf.sh <path-to-input-dat-file> <output-file-name> -Dprintproc
	
	For rr:
	sh run_rr.sh <path-to-input-dat-file> <output-file-name> -Dprintproc
	
We have put in a lot of efforts to assemble this without use of higher level libraries available in cpp and tried to build the schedulers from scratch in c using only structs and malloc which is what OS is all about. Therefore we had a few delays in the submission. Hope you appreciate the detailed construction of the code and show leniency for the late submission if the code impresses you.
