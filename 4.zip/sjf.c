#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// #define PRINT
// #define printproc 

typedef struct burst burst;
typedef struct process process;

struct burst{
    int type;
    int time;
    int time_left;
    burst* next;
};

struct process{
    int pid;
    int arrival;
    int start_time;
    int end_time;
    int cpu_time;
    int io_time;
    int cpu_waiting_time;
    int io_waiting_time;
    burst* b;
    burst* bc;
    process* next;
};

int main(int argc,char*argv[]){
FILE*fi,*fo;
if(argc>2){fo=fopen(argv[2],"w");}
fi=fopen(argv[1],"r");
int lines=0;
int d;
while(fscanf(fi,"%d",&d)!=EOF){if(d==-1)lines++;}
rewind(fi);

process*p=NULL;
int pid=0;
while(fscanf(fi,"%d",&d)!=EOF){
    process*temp=malloc(sizeof(process));
    temp->pid=pid;
    temp->arrival=d;
    temp->start_time=0;
    temp->end_time=0;
    temp->cpu_time=0;
    temp->io_time=0;
    temp->cpu_waiting_time=0;
    temp->io_waiting_time=0;
    temp->next=NULL;
    temp->b=NULL;
    temp->bc=NULL;

    int itype=0;
    while(1){
        fscanf(fi,"%d",&d);
        if(d==-1){
            pid++;
            break;
        }else{
            burst*temb=malloc(sizeof(burst));
            if(itype%2==0){temb->type=0;}
            else{temb->type=1;}
            temb->time=d;
            temb->time_left=d;
            temb->next=NULL;
            itype++;
            if(temp->b==NULL){temp->b=temb; temp->bc=temb;}
            else{burst*trav=temp->b;
            while(trav->next!=NULL){trav=trav->next;}
            trav->next=temb;
            }
        }
    }

    if(p==NULL){p=temp;}
    else{
        if(p->arrival>temp->arrival){
            temp->next=p;
            p=temp;
        }else{ 
            int inserted=0;
            process*trav=p;
            while(trav->next!=NULL){
                if(trav->next->arrival>temp->arrival){
                    temp->next=trav->next;
                    trav->next=temp;
                    inserted=1;
                    break;
                }else{trav=trav->next;}
            }
            if(inserted==0){
                trav->next=temp;
            }
        }
    }

}

//print
#ifdef PRINT
process*travp=p;
while(travp!=NULL){
    printf("P: %d %d %d %d %d %d %d %d\n",
    travp->pid,
    travp->arrival,
    travp->start_time,
    travp->end_time,
    travp->cpu_time,
    travp->io_time,    
    travp->cpu_waiting_time,    
    travp->io_waiting_time
    );
    burst*travb=travp->b;
    while(travb!=NULL){
        printf("B: %d %d %d\n",
        travb->type,
        travb->time,
        travb->time_left
        );
        travb=travb->next;
    }

    travp=travp->next;
    if(travp!=NULL){printf("\n");}
}
#endif
//print

process*cpu=NULL;
process*io=NULL;
process*done=NULL;

int time=0;
while(!(p==NULL && cpu==NULL && io==NULL && !(done==NULL))){
    while(p!=NULL && p->arrival==time){
        if(cpu==NULL){
            cpu=p;
            p=p->next;
            cpu->next=NULL;
        }else{
            if(cpu->bc->time_left>p->bc->time_left && cpu->bc->time_left==cpu->bc->time){
                process*temp=p;
                p=p->next;
                temp->next=cpu;
                cpu=temp;
            }
            else{
                int inserted=0;
                process*travcpu=cpu;
                while(travcpu->next!=NULL){
                    // printf("hello %d\n",time);
                    if(travcpu->next->bc->time_left>p->bc->time_left){
                        process*temp=travcpu->next;
                        travcpu->next=p;
                        p=p->next;
                        travcpu->next->next=temp;
                        inserted=1;
                        break;
                    }
                    travcpu=travcpu->next;
                }{if(p==NULL){break;}}
                if(inserted==0){
                    travcpu->next=p;
                    p=p->next;
                    travcpu->next->next=NULL;
                }
            }   
        }
    }

    //cpu
    if(cpu!=NULL){
        if(cpu->bc->time_left==0){
            process*temp=cpu;
            cpu=cpu->next;
            temp->next=NULL;
            temp->bc=temp->bc->next;
            if(temp->bc!=NULL){
                if(io==NULL){io=temp; io->next=NULL;}
                else{
                    process*travio=io;
                    while(travio->next!=NULL){travio=travio->next;}
                    travio->next=temp;
                    travio->next->next=NULL;
                }
            }else{
                temp->end_time=time;
                if(done==NULL){
                    done=temp;
                }else{
                process*travdone=done;
                while(travdone->next!=NULL){travdone=travdone->next;}
                travdone->next=temp;
                travdone->next->next=NULL;
                }
            }
        }
    }

    //io
    if(io!=NULL){
        if(io->bc->time_left==0){
            process*temp=io;
            io=io->next;
            temp->next=NULL;
            temp->bc=temp->bc->next;
            if(temp->bc!=NULL){
                if(cpu==NULL){
                    cpu=temp;
                }else{
                    if(cpu->bc->time_left>temp->bc->time_left && cpu->bc->time_left==cpu->bc->time){
                        process*temptemp=cpu;
                        cpu=temp;
                        temp->next=temptemp;
                    }
                    else{
                        int inserted=0;
                        process*travcpu=cpu;
                        while(travcpu->next!=NULL){
                            if(travcpu->next->bc->time_left>temp->bc->time_left){
                                process*temptemp=travcpu->next;
                                travcpu->next=temp;
                                travcpu->next->next=temptemp;
                                inserted=1;
                                break;
                            }
                            travcpu=travcpu->next;
                        }
                        if(inserted==0){
                            travcpu->next=temp;
                            travcpu->next->next=NULL;
                        }
                    }
                }
            }else{
                temp->end_time=time;
                if(done==NULL){
                    done=temp;
                }else{
                    process*travdone=done;
                    while(travdone->next!=NULL){travdone=travdone->next;}
                    travdone->next=temp;
                    travdone->next->next=NULL;
                }
            }
        }
    }
if(argc>2){
    int c1=-1,c2=-1,i1=-1,i2=-1;
    if(cpu!=NULL){
        if(cpu->bc==cpu->b && cpu->bc->time==cpu->bc->time_left){cpu->start_time=time;}
        c1=cpu->pid;
        c2=cpu->bc->time_left;
    }
    if(io!=NULL){
        i1=io->pid;
        i2=io->bc->time_left;
    }
    fprintf(fo,"----------- Time: %d ----------------\n",time);
    fprintf(fo,"CPU Process: %d, Time Left: %d\n",c1,c2);
    fprintf(fo,"IO Process: %d, Time Left: %d\n",i1,i2);
    fprintf(fo,"-------------------------------------\n\n");
}
if(cpu!=NULL){
        if(cpu->bc==cpu->b && cpu->bc->time==cpu->bc->time_left){cpu->start_time=time;}
        cpu->bc->time_left--;
        cpu->cpu_time++;
        process* travcpu=cpu->next;
        while(travcpu!=NULL){
            travcpu->cpu_waiting_time++;
            travcpu=travcpu->next;
        }
}
if(io!=NULL){
        io->bc->time_left--;
        io->io_time++;
        process* travio=io->next;
        while(travio!=NULL){
            travio->io_waiting_time++;
            travio=travio->next;
        }
}
time++;
// printf("Time: %d\n",time);
}

//print
#ifdef PRINT
travp=done;
while(travp!=NULL){
    printf("P: %d %d %d %d %d %d %d %d\n",
    travp->pid,
    travp->arrival,
    travp->start_time,
    travp->end_time,
    travp->cpu_time,
    travp->io_time,    
    travp->cpu_waiting_time,    
    travp->io_waiting_time
    );
    burst*travb=travp->b;
    while(travb!=NULL){
        printf("B: %d %d %d\n",
        travb->type,
        travb->time,
        travb->time_left
        );
        travb=travb->next;
    }
    travp=travp->next;
    if(travp!=NULL){printf("\n");}
}
#endif
//print

process display[lines];
float data[lines][5];
float avg[5];
process* travdone=done;
while(travdone!=NULL){
    int pid=travdone->pid;
    display[pid].pid=pid;
    display[pid].arrival=travdone->arrival;
    display[pid].start_time=travdone->start_time;
    display[pid].end_time=travdone->end_time;
    display[pid].cpu_time=travdone->cpu_time;
    display[pid].io_time=travdone->io_time;
    display[pid].cpu_waiting_time=travdone->cpu_waiting_time;
    display[pid].io_waiting_time=travdone->io_waiting_time;

    // turnaround time
    data[pid][0]=display[pid].end_time-display[pid].arrival;   
    avg[0]+=data[pid][0];    
    
    // waiting time
    data[pid][1]=display[pid].cpu_waiting_time;
    avg[1]+=data[pid][1];
    
    // response time
    data[pid][2]=display[pid].start_time-display[pid].arrival;
    avg[2]+=data[pid][2];
    
    // service time
    data[pid][3]=display[pid].cpu_time;
    avg[3]+=data[pid][3];

    // penalty ratio
    data[pid][4]=(float)display[pid].cpu_time/(float)(display[pid].cpu_time+display[pid].cpu_waiting_time);
    avg[4]+=data[pid][4];

    travdone=travdone->next;
}
#ifndef printproc
for(int pid=0;pid<lines;pid++){
    printf("\n-----------Process ID: %d--------------------\n",display[pid].pid);
    printf("Turnaround time: %.0lf\n",data[pid][0]);
    printf("Waiting time: %.0lf\n",data[pid][1]);
    printf("Response time: %.0lf\n",data[pid][2]);
    printf("Service time: %.0lf\n",data[pid][3]);
    printf("Penalty ratio: %.5lf\n",data[pid][4]);
    printf("--------------------------------------------\n\n");
}
#endif

    printf("\n-----------System Averages------------------\n");
    printf("Turnaround time: %.5lf\n",avg[0]/lines);
    printf("Waiting time: %.5lf\n",avg[1]/lines);
    printf("Response time: %.5lf\n",avg[2]/lines);
    printf("Service time: %.5lf\n",avg[3]/lines);
    printf("Penalty ratio: %.5lf\n",avg[4]/lines);
    printf("Average time for process: %.5lf\n",(float)time/(float)lines);
    printf("Throughput (processes per second): %.5lf\n",(float)lines/(float)time);
    printf("--------------------------------------------\n\n");

process*freemem=done;
while(freemem!=NULL){
    process*temp=freemem;
    freemem=freemem->next;
    burst* travburst=temp->b;
    while(travburst!=NULL){
        burst*tempb=travburst;
        travburst=travburst->next;
        free(tempb);
    }
    free(temp);
}

fclose(fi);
if(argc>2){fclose(fo);}
    return 0;
}