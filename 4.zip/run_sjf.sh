sh prep.sh $1 temp_vvn_sjf.txt
gcc sjf.c -g -Wall -o sjf $3
./sjf temp_vvn_sjf.txt $2
rm temp_vvn_sjf.txt