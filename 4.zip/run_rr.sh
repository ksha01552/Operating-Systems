sh prep.sh $1 temp_vvn_rr.txt
gcc rr.c -g -Wall -o rr $3
./rr temp_vvn_rr.txt $2
rm temp_vvn_rr.txt