print("--------------------------------------")
print("To translate the address for segment 0")
print("--------------------------------------")
for i in range(0,20):
    print(f"{i} VA is mapped to {i} PA")

print("----------------------------------------------------------------")
a = []
print()
print("----------------------------------------------------------------")
print("To translate the address for segment 1 which is slightly tricky")
print("----------------------------------------------------------------")
for i in range(511, 100, -1):
    if len(a) > 20:
        break
    a.append(i)

b=[]
for j in range(127, 100, -1):
    if len(b) > 20:
        break
    b.append(j)

for i in range(20):
    print(f"{b[i]} VA is mapped to {a[i]} PA")

print("----------------------------------------------------------------")